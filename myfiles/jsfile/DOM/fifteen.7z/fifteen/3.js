/* var yh  = document.querySelector("input[name=username]");
yh.onFocus = function(){
    yh.className = "txt_focus";
} */


var inp = document.getElementsByName("username")[0];
var inpwd = document.getElementsByName("pwd")[0];
inp.onfocus = function(){
    this.className = "txt_focus";
    var div = this.parentNode.nextElementSibling.children[0];
    div.className = "";
}
/* inp.onblur = function(){
    var reg = /^\w{1,10}$/;
    this.className = "";
    if(reg.test(this.value)){
        var div = this.parentNode.nextElementSibling.children[0];
        div.className = "vali_success";
    }else{
        var div = this.parentNode.nextElementSibling.children[0];
        div.className = "vali_fail";
    }
} */

/* inpwd.onblur = function(){
    var reg = /^[0-9]{6}$/;
    this.className = "";
    var div = this.parentNode.nextElementSibling.children[0];
    if(reg.test(this.value)){
        div.className = "vali_success";
    }else{
        div.className = "vali_fail";
    }
} */

function vail(txt,reg){
    txt.className = "";
    var div = txt.parentNode.nextElementSibling.children[0];
    if(reg.test(txt.value)){
        div.className = "vali_success";
    }else{
        div.className = "vali_fail";
    }
}
inpwd.onblur = function(){
    vail(this,/^\d{6}$/);
}
inp.onblur = function(){
    vail(this,/^\w{1,10}$/);
}

inpwd.onfocus = function(){
    this.className = "txt_focus";
    var div = this.parentNode.nextElementSibling.children[0];
    div.className = "";
}


/* var people  = document.querySelectorAll("input");
console.log(people);
for(var p of people){
    p.onfocus =  function(){
        this.className = "txt_focus";
        var div = this.parentNode.nextElementSibling.children[0];
        div.className = "";
    }
} */
